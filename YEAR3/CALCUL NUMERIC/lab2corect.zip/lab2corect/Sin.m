function C=Sin(x)
    %facem reducere la primul cadran
    x=mod(x, 2*pi);
    val=1;
    if x >= pi/2 && x<pi
        x=pi-x;
    elseif x>=pi && x<3*pi/2
        val=-1;
        x=x-pi;
    elseif x>=3*pi/2
        x=2*pi-x;
        val=-1;
    end

    x_la_putere=x;
    factorial=1;
    polinom=0;
    for i=1:10
        polinom=polinom+x_la_putere/factorial;
        x_la_putere=-x_la_putere*x^2;
        factorial=factorial*(2*i)*(2*i+1);
    end
    C=val*polinom;
end

% syms x
% Sin(x)