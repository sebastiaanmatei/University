function C = Cos(x)
    % Reduce x to the first quadrant
    x = mod(x, 2*pi);
    val = 1;
    if x >= pi/2 && x < pi
        x = pi - x;
    elseif x >= pi && x < 3*pi/2
        val = -1;
        x = x - pi;
    elseif x >= 3*pi/2
        x = 2*pi - x;
        val = -1;
    end

    x_power = x;
    factorial = 1;
    polynomial = 0;
    for i = 1:10
        polynomial = polynomial + x_power / factorial;
        x_power = -x_power * x^2;
        factorial = factorial * (2*i) * (2*i);
    end
    C = val * polynomial;
end
