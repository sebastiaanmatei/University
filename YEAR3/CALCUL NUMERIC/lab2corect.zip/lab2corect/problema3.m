syms x;
format longg

valoare=pi/3;
disp(['Functia sin cu pade: ']);
disp(sin(valoare));
disp(Sin(valoare));
disp(SinPade(valoare));


%functia cos:
disp(['Functia cos: ']);
disp(cos(valoare));
disp(cos_lab02(valoare));
disp(CosPade(valoare));


%f=sin(x);
%m=3;
%k=3;
%aproximare_pade(f,m,k);