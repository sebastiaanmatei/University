function c=taylor_coef(f,n)
    c=sym(subs(diff(f,n),0)/factorial(n));
end %calculeaza coeficientul n din seria taylor a unei functii
