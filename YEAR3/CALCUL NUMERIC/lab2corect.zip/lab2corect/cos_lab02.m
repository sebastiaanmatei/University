function result = cos_lab02(x)
    % reducere la cadranul I:
    x=mod(x, 2*pi);
    sign=1;
    if x >= pi/2 && x<pi
        x=pi-x;
    elseif x>=pi && x<3*pi/2
        sign=-1;
        x=x-pi;
    elseif x>=3*pi/2        
        sign=1;
        x=2*pi-x;
    end

    syms aux;
    factorial = 1;
    semn = 1;
    taylor = 0;
    putere = 1;
    n=0;

    for n=0:2:10
        taylor =  taylor + semn*putere/factorial;

        putere = putere*x*x;
        factorial = factorial * (n+1) * (n+2);
        semn = semn*(-1);
        
    end
    result = sign * taylor;
   end