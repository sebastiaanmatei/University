syms x;
format longg
%aproximarea pentru x=2kpi cu k mare devine mai ne accurate pt ca punctul in care vrem sa
%calculam val cos/sin e mai departe de 0(valoarea in care e centrata
%functie taylor)
%remediu = facem reducere la primul cadran
k=1000;
%functia sin:
valoare=k*(pi/3);
alta_valoare=2*k*pi;
noua_valoare=(2*k+1)*pi;

disp(['pentru sin: ']);
disp(Sin(valoare));
disp(sin(valoare));

%functia cos:
disp(['pentru cos: ']);
disp(cos_lab02(valoare));
disp(cos(valoare));


