#pragma once

void testAllExtins();
