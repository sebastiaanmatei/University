#include "MD.h"
#include "IteratorMD.h"
#include <exception>
#include <vector>
#include <math.h>
#include <iostream>
#define NIL -1
using namespace std;

//typedef struct structure structure;

MD::MD() {
    m = MAX;
    for(int i=0;i<m;i++){
        e[i].key = NIL;
    }
}


int MD::hashCode(TCheie c) const {

    return c % m;
}

int MD::d(TCheie c, int i) const {
    //cout<<hashCode(c)<<endl;
    return int(hashCode(c)+ (i+pow(i, 2))/2) % m;
}


void MD::adauga(TCheie c, TValoare v) {
    vector<TValoare> values=cauta(c);
    if(values.empty()){//daca nu exista cheia
        //cout<<"nu gasit"<<c<<endl;
        if(e[hashCode(c)].key==NIL){
            //cout<<"ADAUGA"<<endl;
            e[hashCode(c)].key=c;
            e[hashCode(c)].array.push_back(v);
            cout<<hashCode(c)<<" "<<e[hashCode(c)].key<<" values: ";
            for(int i=0;i<e[hashCode(c)].array.size();i++){
                cout<<e[hashCode(c)].array.at(i)<<" ";
            }
            cout<<endl;
        }else{
            //cout<<"ADAUGA2"<<endl;
            bool found=false;
            int i=0;
            while(!found && i<m){
                int position=d(c, i);
                if(e[position].key==NIL){
                    e[position].key=c;
                    e[position].array.push_back(v);
                    found=true;

                    cout<<position<<" "<<e[position].key<<endl;
                    break;
                }else{
                    i++;
                }
            }
        }

    }else{
        //cout<<"gasit"<<c<<endl;
        vector<TValoare> values;
        values=cauta(c);
        values.push_back(v);
        e[hashCode(c)].array=values;
        cout<<hashCode(c)<<" "<<e[hashCode(c)].key<<" values: ";
        for(int i=0;i<e[hashCode(c)].array.size();i++){
            cout<<e[hashCode(c)].array.at(i)<<" ";
        }
        cout<<endl;
    }
    //cout<<c<<


}


bool MD::sterge(TCheie c, TValoare v) {
    /* de adaugat */
    return false;
}


vector<TValoare> MD::cauta(TCheie c) const {
    //cout<<"Y";
    bool found=false;
    int pos=-1;
    int i=0;
    while(!found && i<m){
        //cout<<c<<endl;
        //int i=0;
        //cout<<"input:"<<c<<" "<<i<<endl;
        int position=d(c, i);
        //cout<<"output:"<<c<<" "<<i<<endl;
        //cout<<"output"<<position<<endl;
        if(e[position].key==c){
            pos=position;
            found=true;
            break;

        }else{
            i++;
        }
    }
    if(pos!=-1){
        //cout<<"o gasit cheia"<<c<<endl;
        return e[pos].array;
    }else{
        //cout<<"nu o gasit cheia"<<c<<endl;
        return {};
    }


}


int MD::dim() const {
    /* de adaugat */
    return m;
}


bool MD::vid() const {
    /* de adaugat */
    return m==0;
}

IteratorMD MD::iterator() const {
    return IteratorMD(*this);
}


MD::~MD() {
    /* de adaugat */
}

