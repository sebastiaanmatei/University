package com.example.myfacebook.exceptions;

public class ServiceException extends Exception{
    public ServiceException(String message) {
        super(message);
    }
}
