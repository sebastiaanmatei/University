package com.example.myfacebook.utils.events;

public interface Event {
}
