package com.example.examenmap.domain;

public enum TipuriOrase {
    Cluj,
    Bistrita,
    Sibiu,
    Brasov
}
