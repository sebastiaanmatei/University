package com.example.examenmap.utils.events;

public interface Event {
}
