package com.example.examenmap.utils.events;

public class EntityChangeEvent implements Event {
    private com.example.examenmap.utils.events.ChangeEventType type;
    //private Checkup data, oldData;

    /*public EntityChangeEvent(com.example.practice2.utils.events.ChangeEventType type, Checkup data) {
        this.type = type;
        //this.data = data;
    }
    public EntityChangeEvent(com.example.practice2.utils.events.ChangeEventType type, Checkup data, Checkup oldData) {
        this.type = type;
        //this.data = data;
        //this.oldData=oldData;
    }

    public com.example.practice2.utils.events.ChangeEventType getType() {
        return type;
    }

    //public Checkup getData() {
        //return data;
    //}

    //public Checkup getOldData() {
        //return oldData;
    //}*/
}
