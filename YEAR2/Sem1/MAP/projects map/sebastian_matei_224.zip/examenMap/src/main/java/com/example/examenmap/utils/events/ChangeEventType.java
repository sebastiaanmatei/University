package com.example.examenmap.utils.events;

public enum ChangeEventType {
    ADD,UPDATE,DELETE;
}
