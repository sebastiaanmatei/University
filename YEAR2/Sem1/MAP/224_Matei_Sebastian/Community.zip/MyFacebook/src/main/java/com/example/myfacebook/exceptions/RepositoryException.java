package com.example.myfacebook.exceptions;

public class RepositoryException extends Exception {
    public RepositoryException(String message) {
        super(message);
    }
}
