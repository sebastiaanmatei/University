package com.example.characteristics.domain;


import javax.persistence.Table;

@javax.persistence.Entity
@Table( name = "games" )
public class Game extends Entity<Integer>{
    String us1, us2, us3;
    String status;
    public Game(Integer id, String us1, String us2, String us3, String status) {
        super.setId(id);

        this.us1=us1;
        this.us2=us2;
        this.us3=us3;
        this.status=status;
    }

    public Game() {

    }

    public String getUs1() {
        return us1;
    }

    public void setUs1(String us1) {
        this.us1 = us1;
    }

    public String getUs2() {
        return us2;
    }

    public void setUs2(String us2) {
        this.us2 = us2;
    }

    public String getUs3() {
        return us3;
    }

    public void setUs3(String us3) {
        this.us3 = us3;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
