package com.example.characteristics.domain;

public class ContainerGR extends Entity<Integer>{
    Game game;
    Round round;

    public ContainerGR(Integer id, Game game, Round round) {
        super.setId(id);
        this.game = game;
        this.round = round;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public Round getRound() {
        return round;
    }

    public void setRound(Round round) {
        this.round = round;
    }
}
