package com.example.characteristics.repo;

import com.example.characteristics.domain.Entity;
import org.springframework.stereotype.Repository;

import java.io.Serializable;

@Repository
public interface WordRepo <ID extends Serializable> {
    String findOne (int id);

}