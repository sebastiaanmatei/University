package com.example.characteristics.repo;

import com.example.characteristics.domain.Entity;
import com.example.characteristics.domain.Statistic;
import com.example.characteristics.domain.User;

import java.io.Serializable;
import java.util.List;

public interface StatsRepo <ID extends Serializable, E extends Entity<ID>>{

    E findOne (int id);

    List<Statistic> findAll();

    void save(Statistic user);

    void update(Integer id, Statistic user);

    void delete(String username);

    List<Statistic> findByGame(ID id);
}
