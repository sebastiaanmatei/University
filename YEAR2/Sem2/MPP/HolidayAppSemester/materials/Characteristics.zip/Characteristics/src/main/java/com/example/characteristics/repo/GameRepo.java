package com.example.characteristics.repo;

import com.example.characteristics.domain.Entity;
import com.example.characteristics.domain.Game;
import com.example.characteristics.domain.Statistic;

import java.io.Serializable;
import java.util.List;

public interface GameRepo <ID extends Serializable, E extends Entity<ID>>{

    E findOne (int id);

    List<Game> findAll();

    void save(Game user);

    void update(Integer id, Game user);

}
