package com.example.characteristics.networking.rpcprotocol;



import com.example.characteristics.domain.*;
import com.example.characteristics.service.TripService;
import com.example.characteristics.utils.observer.ITripsObserver;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import java.util.Random;

public class TripClientRpcWorker implements Runnable, ITripsObserver {
    private TripService service;
    private Socket connection;
    private ObjectInputStream input;
    private ObjectOutputStream output;
    private volatile boolean connected;


    public TripClientRpcWorker(TripService service, Socket connection){
        this.service=service;
        this.connection=connection;
        try{
            output=new ObjectOutputStream(connection.getOutputStream());
            output.flush();
            input=new ObjectInputStream(connection.getInputStream());
            connected=true;
        }
        catch (IOException ex){
            ex.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (connected){

            try{
                Object request=input.readObject();
                Response response=handleRequest((Request)request);
                if (response!=null)
                    sendResponse(response);
            }
            catch (IOException e){
                e.printStackTrace();
            }
            catch (ClassNotFoundException e){
                e.printStackTrace();
            }

            try{
                Thread.sleep(1000);
            }
            catch (InterruptedException ex){
                ex.printStackTrace();
            }
        }
    }

    private void sendResponse(Response response) throws IOException{
        System.out.println("sending response "+response);
        output.writeObject(response);
        output.flush();
    }



//    @Override
//    public void ticketBought(Ticket ticket) {
//        try{
//            sendResponse(new Response.Builder().type(ResponseType.BUY_TICKET).data(ticket).build());
//        }
//        catch (IOException e){
//            e.printStackTrace();
//        }
//    }


    private Response handleRequest(Request request){
        Response response=null;
        if (request.type()== RequestType.LOGIN){
            System.out.println("intra pe login");
            User employee=(User)request.data();
            try{
                User found_employee=service.login(employee,this);
                return new Response.Builder().type(ResponseType.OK).data(found_employee).build();
            }
            catch (Exception e){
                connected=false;
                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
            }
        }

        if (request.type()== RequestType.LOGOUT){
            User employee=(User)request.data();
            try{
                service.logout(employee,this);
                connected=false;
                return new Response.Builder().type(ResponseType.OK).build();
            }
            catch (Exception e){
                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
            }
        }

        if (request.type()== RequestType.START){
            System.out.println("intra pe start");
            User grp=(User)request.data();
            String usname=grp.getUsername();
            try{
                System.out.println("intra pe start try");
                ContainerGR g=service.start(usname,this);
                System.out.println(g.getGame());
                if(g.getGame()!=null){
                    System.out.println("x");
                    return new Response.Builder().type(ResponseType.OK).data(g).build();
                }
                return new Response.Builder().type(ResponseType.OK).data(g).build();

            }
            catch (Exception e){
                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
            }
        }

        if (request.type()== RequestType.ROUND){
            Round grp=(Round)request.data();
            try{
                ContainerLinesRound results =service.round(grp);
                //List<Roundline> lins= results.getLines();
                if(results!=null){
                    return new Response.Builder().type(ResponseType.OK).data(results).build();
                }else{
                    return new Response.Builder().type(ResponseType.OK).data(results).build();
                }
            }
            catch (Exception e){
                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
            }
        }

        if (request.type()== RequestType.GET_STATS){
            Game grp=(Game)request.data();
            try{
                List<Statistic> stats=service.getStats(grp,this);
                return new Response.Builder().type(ResponseType.OK).data(stats).build();
            }
            catch (Exception e){
                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
            }
        }


        if (request.type()== RequestType.SEND_OPTIONS){
            Roundline grp=(Roundline)request.data();
            try{
                Roundline rline=service.scoreIt(grp,this);
                return new Response.Builder().type(ResponseType.SEND_OPTIONS).data(rline).build();
            }
            catch (Exception e){
                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
            }
        }


        return response;
    }


    @Override
    public void updateRound(ContainerLinesRound container) {
        try{
            sendResponse(new Response.Builder().type(ResponseType.ROUND).data(container).build());
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void updateStats(List<Statistic> round) {
        try{
            sendResponse(new Response.Builder().type(ResponseType.GET_STATS).data(round).build());
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void start(Game newGame, Round newRound) {
        Random rand = new Random(); //instance of random class
        int upperbound = 10000;
        int id = rand.nextInt(upperbound);
        ContainerGR cont=new ContainerGR(id, newGame, newRound);
        try{
            sendResponse(new Response.Builder().type(ResponseType.START).data(cont).build());
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}
