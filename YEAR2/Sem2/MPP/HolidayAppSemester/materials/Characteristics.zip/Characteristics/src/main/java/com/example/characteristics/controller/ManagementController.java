package com.example.characteristics.controller;



import com.example.characteristics.domain.*;
import com.example.characteristics.networking.rpcprotocol.TripServicesRpcProxy;
import com.example.characteristics.utils.observer.ITripsObserver;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;

import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class ManagementController implements ITripsObserver, Initializable {

    //ProtoProxy service;
    TripServicesRpcProxy service;
    User loggedInUser;
    Round currentRound;
    Game currentGame;

    ObservableList<Roundline> Tmodel = FXCollections.observableArrayList();
    ObservableList<Statistic> T2model = FXCollections.observableArrayList();


    @FXML
    Text userName;

    @FXML
    Text opp1;
    @FXML
    Text opp2;

    @FXML
    Text word;

    @FXML
    Button startButton;

    @FXML
    Button logOutButton;

    @FXML
    Button sendButton;

    @FXML
    Button statsButton;

    @FXML
    TextField optField1;

    @FXML
    TextField optField2;

    @FXML
    private TableView<Roundline> tableRound;
    @FXML
    private TableView<Statistic> tableStats;

    @FXML
    private TableColumn userCol;
    @FXML
    private TableColumn op1Col;
    @FXML
    private TableColumn op2Col;
    @FXML
    private TableColumn scoreCol;
    @FXML
    private TableColumn userStats;
    @FXML
    private TableColumn scoreStats;



    public void setService(TripServicesRpcProxy service) {
        this.service = service;
        //service.addObserver(this);
        initModel();
        this.currentGame=null;
        this.currentRound=null;
    }

    void initialize() {
        userCol.setCellValueFactory(new PropertyValueFactory<Roundline, String>("player"));
        op1Col.setCellValueFactory(new PropertyValueFactory<Roundline, String>("option1"));
        op2Col.setCellValueFactory(new PropertyValueFactory<Roundline, String>("option2"));
        scoreCol.setCellValueFactory(new PropertyValueFactory<Roundline, Integer>("score"));
        tableRound.setItems(Tmodel);

        userStats.setCellValueFactory(new PropertyValueFactory<Statistic, String>("player"));
        scoreStats.setCellValueFactory(new PropertyValueFactory<Statistic, String>("score"));
        tableStats.setItems(T2model);
    }

    void initData(User user) {
        userName.setText(user.getUsername());
        initialize();
        this.loggedInUser = user;
    }

    private void initModel() {
//        List<Trip> messages = null;
//        try {
//            messages = (List<Trip>) service.getAllTrips();
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//        List<Trip> trips = StreamSupport.stream(messages.spliterator(), false)
//                .collect(Collectors.toList());
//        Tmodel.setAll(trips);
    }

    @FXML
    private void startGame(){

        try {
            boolean isStarted=service.start(loggedInUser, this);
            System.out.println(isStarted);
            if(!isStarted){
                System.out.println("sadsa");
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Info", "- Game not started yet! Please wait for other players! -");

            }else{
                System.out.println("izeze");
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Info", "- Started -");

            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @FXML
    private void sendLine(){

        Random rand = new Random(); //instance of random class
        int upperbound = 10000;
        int id = rand.nextInt(upperbound);

        String opt1=optField1.getText();
        String opt2=optField2.getText();

        int idr=currentRound.getId();
        ContainerLinesRound container=null;
        Roundline line=new Roundline(id, loggedInUser.getUsername(), opt1, opt2, 0, idr);
        try {
            service.sendLine(line, this);
            container=service.round(currentRound);

            if(container!=null){
                updateRound(container);

            }else{
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Info", " Waiting for other players to answer ... ");
            }

            //id = rand.nextInt(upperbound);


        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }



    @FXML
    public void onLogOut(ActionEvent actionEvent) {
        try {
            service.logout(loggedInUser,this);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        ((Node)(actionEvent.getSource())).getScene().getWindow().hide();


    }

//    @Override
//    public void booky(Reservation reservation) {
//
//    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    @Override
    public void updateRound(ContainerLinesRound container) {

        Platform.runLater(() -> {
            try {
                List<Roundline>lines=container.getLines();
                initLists(lines);

                currentRound=container.getRnd();
                if(currentRound.getNumberOf()<=3){
                    word.setText(currentRound.getWord());
                    optField1.clear();
                    optField2.clear();
                    currentRound.setIdGame(currentGame.getId());

                    MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Info", " Round "+currentRound.getNumberOf());

                }else{
                    seeStats();
                }


            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    @Override
    public void updateStats(List<Statistic> lines) {
        Platform.runLater(() -> {
            try {
                initLists2(lines);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    @Override
    public void start(Game newGame, Round newRound) {
        System.out.println("trece prin start la inceput");
        if(newGame!=null && newRound!=null){

            System.out.println("trece prin start1111??");
            currentGame=newGame;
            currentRound=newRound;
            currentRound.setIdGame(currentGame.getId());

            opp1.setText(currentGame.getUs2());
            opp2.setText(currentGame.getUs3());
            word.setText(currentRound.getWord());

            System.out.println(currentGame.getId());
            System.out.println("o actualizat");
            System.out.println(opp1.getText());
            System.out.println(opp2.getText());
            System.out.println(word.getText());

            //MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Info", "- Game started! Good luck! -");

        }



    }

    @FXML
    private void seeStats(){
        try {
            List<Statistic> stattts= service.getStats(currentGame);
            initLists2(stattts);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void initLists2(List<Statistic> stats) {
        try {
            if(stats!=null){

                Collections.sort(stats, Comparator.comparingInt(Statistic::getScore).reversed());
                T2model.setAll(stats);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    private void initLists(List<Roundline> lines) {
        try {
            //List<Roundline> round=service.round(currentRound).getLines();
            if(lines!=null){
                //modelStock.setAll(stockFinal);
                Collections.sort(lines, Comparator.comparingInt(Roundline::getScore).reversed());

                Tmodel.setAll(lines);
            }else{
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Info", " Waiting for other players answer .. ");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }




//    @Override
//    public void booky(Reservation reservation) {
//        System.out.println("intra prin update u booky din cacatu asta infect de management");
//        Platform.runLater(() -> {
//            try {
//                initLists();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        });
//
//
//        System.out.println("o fc update u din management ccu platform runner");
//
//    }
//
//    private void initLists() {
//        try {
//            Tmodel.setAll(service.getAllTrips());
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//
//    }
//
//    @Override
//    public void initialize(URL location, ResourceBundle resources) {
//
//    }
}

