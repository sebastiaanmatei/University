package com.example.characteristics.utils.events;

public enum ChangeEventType {
    ADD,UPDATE,DELETE;
}
