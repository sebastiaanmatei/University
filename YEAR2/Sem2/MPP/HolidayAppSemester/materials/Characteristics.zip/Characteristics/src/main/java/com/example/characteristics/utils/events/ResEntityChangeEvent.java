package com.example.characteristics.utils.events;


import com.example.characteristics.domain.Game;

public class ResEntityChangeEvent implements Event {
    private ChangeEventType type;
    private Game data, oldData;

    public ResEntityChangeEvent(ChangeEventType type, Game data) {
        this.type = type;
        this.data = data;
    }
    public ResEntityChangeEvent(ChangeEventType type, Game data, Game oldData) {
        this.type = type;
        this.data = data;
        this.oldData=oldData;
    }

    public ChangeEventType getType() {
        return type;
    }

    public Game getData() {
        return data;
    }

    public Game getOldData() {
        return oldData;
    }
}