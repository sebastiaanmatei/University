package com.example.characteristics.repo;

import com.example.characteristics.domain.Game;
import com.example.characteristics.domain.Roundline;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.List;

public class RLineHbnRepo implements RoundlineRepo<Integer, Roundline> {

    SessionFactory sessionFactory;

    public RLineHbnRepo(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public Roundline findOne(int id) {
        return null;
    }

    @Override
    public List<Roundline> findAll() {
        return null;
    }

    @Override
    public void save(Roundline order) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                session.save(order);
                tx.commit();
            } catch (RuntimeException ex) {
                System.err.println("Eroare la insert "+ex);
                if (tx != null)
                    tx.rollback();
            }
        }
    }

    @Override
    public void update(Integer id, Roundline user) {

    }

    @Override
    public List<Roundline> findResultsForRound(Integer id) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();

                org.hibernate.Query<Roundline> query1 = session.createQuery("from Roundline where idRound=: id", Roundline.class);
                query1.setParameter("id", id);
                List<Roundline> usr1= query1.getResultList();

                tx.commit();
                return usr1;
            } catch (RuntimeException ex) {
                ex.printStackTrace();
                System.err.println("Eroare la select "+ex);
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

}
