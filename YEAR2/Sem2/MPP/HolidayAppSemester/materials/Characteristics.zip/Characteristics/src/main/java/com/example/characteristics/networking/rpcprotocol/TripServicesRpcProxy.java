package com.example.characteristics.networking.rpcprotocol;

import com.example.characteristics.domain.*;
import com.example.characteristics.utils.observer.ITripsObserver;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class TripServicesRpcProxy {
    private String host;
    private int port;
    private ITripsObserver client;
    private ObjectInputStream input;
    private ObjectOutputStream output;
    private Socket connection;
    private BlockingQueue<Response> qresponses;
    private volatile boolean finished;

    public TripServicesRpcProxy(String host, int port) {
        this.host = host;
        this.port = port;
        qresponses=new LinkedBlockingQueue<>();
    }


    private class ReaderThread implements Runnable{
        @Override
        public void run() {
            while(!finished){
                try{
                    Object response=input.readObject();
                    System.out.println("Response received"+response);
                    if (isUpdate((Response) response) || isUpdate2((Response) response) || isUpdate3((Response) response)){
                        handleUpdate((Response) response);
                    }
                    else{
                        try{
                            qresponses.put((Response) response);
                        }
                        catch (InterruptedException ex){
                            System.out.println("Error "+ex);
                        }
                    }

                }
                catch (IOException | ClassNotFoundException ex){
                    //ex.printStackTrace();
                    System.out.println("Reading error "+ex);
                }
            }
        }
    }

    private void sendRequest(Request request) throws Exception{
        try{
            output.writeObject(request);
            output.flush();
        }
        catch (IOException ex){
            throw new Exception("Error sending object "+ex);
        }
    }

    private Response readResponse() throws Exception{
        Response response=null;
        try{
            response=qresponses.take();
        }
        catch (InterruptedException ex){
            ex.printStackTrace();
        }
        return response;
    }

    private void initConnection() throws Exception {
        connection=new Socket(host,port);
        output=new ObjectOutputStream(connection.getOutputStream());
        output.flush();
        input=new ObjectInputStream(connection.getInputStream());
        finished=false;
        startReader();
    }
    private void closeConnection(){
        finished=true;
        try{
            input.close();
            output.close();
            connection.close();
            client=null;

        }
        catch (IOException ex){
            ex.printStackTrace();
        }
    }
    private void startReader(){
        Thread tw=new Thread(new ReaderThread());
        tw.start();
    }
    private boolean isUpdate(Response response){
        return response.type()==ResponseType.ROUND;
    }

    private boolean isUpdate2(Response response){
        return response.type()==ResponseType.GET_STATS;
    }

    private boolean isUpdate3(Response response){
        return response.type()==ResponseType.START;
    }

    private void handleUpdate(Response response){
        if (response.type()==ResponseType.ROUND){
            ContainerLinesRound lines=(ContainerLinesRound) response.data();
            client.updateRound(lines);
        }
        if (response.type()==ResponseType.GET_STATS){
            List<Statistic> ticket=(List<Statistic>) response.data();
            client.updateStats(ticket);
        }
        if (response.type()==ResponseType.START){
            ContainerGR container= (ContainerGR) response.data();
            Game g=container.getGame();
            Round r=container.getRound();
            client.start(g,r);
        }
    }


    public User login(User employee, ITripsObserver client) throws Exception {
        initConnection();
        Request req=new Request.Builder().type(RequestType.LOGIN).data(employee).build();
        sendRequest(req);
        Response response=readResponse();
        if (response.type()==ResponseType.OK){
            this.client=client;
            User employee_to_connect=(User) response.data();
            return employee_to_connect;
        }
        if (response.type()==ResponseType.ERROR){
            String err=response.data().toString();
            closeConnection();
            throw new Exception(err);
        }

        return null;
    }

    public void logout(User employee, ITripsObserver client) throws Exception {
        Request req=new Request.Builder().type(RequestType.LOGOUT).data(employee).build();
        sendRequest(req);
        Response response=readResponse();
        closeConnection();
        if (response.type()==ResponseType.ERROR){
            String err=response.data().toString();
            throw new Exception(err);
        }
    }


    public List<Statistic> getStats(Game grp) throws Exception{
        Request req=new Request.Builder().type(RequestType.GET_STATS).data(grp).build();
        sendRequest(req);
        Response response=readResponse();
        if (response.type()==ResponseType.OK){
            List<Statistic> stats= (List<Statistic>) response.data();
            return stats;
        }
        else
            throw new Exception("Error getting flights");
    }

    public synchronized boolean start(User usr, ITripsObserver client) throws Exception{
        Request req=new Request.Builder().type(RequestType.START).data(usr).build();
        sendRequest(req);
        Response response=readResponse();
        //System.out.println(response);
        System.out.println(response.toString()+" o primit response");
        if (response.type()==ResponseType.OK ){
            System.out.println("o primit response ok" + usr.getUsername());
            return false;
        }
        else
            throw new Exception("Error starting game blablabal");

    }

    public ContainerLinesRound round(Round grp) throws Exception{

        Request req=new Request.Builder().type(RequestType.ROUND).data(grp).build();
        sendRequest(req);
        Response response=readResponse();
        if (response.type()==ResponseType.ROUND){
            ContainerLinesRound trips= (ContainerLinesRound) response.data();
            return trips;
        }else if(response.type()==ResponseType.OK){
            return (ContainerLinesRound) response.data();
        }
        else
            throw new Exception("Error getting flights");

    }

    public Roundline sendLine(Roundline line, ITripsObserver client) throws Exception{

        Request req=new Request.Builder().type(RequestType.SEND_OPTIONS).data(line).build();
        sendRequest(req);
        Response response=readResponse();
        if (response.type()==ResponseType.SEND_OPTIONS){
            Roundline linev=(Roundline) response.data();
            return linev;
        }
        else
            throw new Exception("Error getting flights");

    }





//    public void roundPlay(Integer idTrip, String clientx, String phone, Integer tickets) throws Exception{
//        Random rand = new Random(); //instance of random class
//        int upperbound = 10000;
//        int id = rand.nextInt(upperbound);
//        Reservation ticket=new Reservation(id,idTrip,clientx,phone,tickets);
//        Request req=new Request.Builder().type(RequestType.RESERVATION).data(ticket).build();
//        sendRequest(req);
//        Response response=readResponse();
//
//        System.out.println("daca vine bn pana aici in book in serv proxy "+response.type());
//        if (response.type() == ResponseType.ERROR) {
//            String err = response.data().toString();
//            throw new Exception(err);
//        }
//
//    }

//    public List<Trip> getFiltered(String destination, Integer hourFrom, Integer hourTo) throws Exception{
//        FilterContainer flc=new FilterContainer(destination, hourFrom,hourTo);
//        Request req=new Request.Builder().type(RequestType.GET_FILTERED).data(flc).build();
//        sendRequest(req);
//        Response response=readResponse();
//        if (response.type()==ResponseType.GET_FILTERED){
//            List<Trip> trips= (List<Trip>) response.data();
//            return trips;
//        }
//        else
//            throw new Exception("Error getting flights");
//    }
//
//    public void book(Integer idTrip, String clientx, String phone, Integer tickets) throws Exception{
//        Random rand = new Random(); //instance of random class
//        int upperbound = 10000;
//        int id = rand.nextInt(upperbound);
//        Reservation ticket=new Reservation(id,idTrip,clientx,phone,tickets);
//        Request req=new Request.Builder().type(RequestType.RESERVATION).data(ticket).build();
//        sendRequest(req);
//        Response response=readResponse();
//
//        System.out.println("daca vine bn pana aici in book in serv proxy "+response.type());
//        if (response.type() == ResponseType.ERROR) {
//            String err = response.data().toString();
//            throw new Exception(err);
//        }
//
//    }
//
//    public List<Trip> getAllTrips() throws Exception{
//        Request request=new Request.Builder().type(RequestType.GET_ALL_TRIPS).data(null).build();
//        sendRequest(request);
//        Response response=readResponse();
//        if (response.type()==ResponseType.GET_ALL_TRIPS){
//            List<Trip> trips=(List<Trip>) response.data();
//            return trips;
//        }
//        else
//            throw new Exception("Error getting flights");
//
//
//    }





}
