package com.example.characteristics.repo;

import com.example.characteristics.domain.Entity;
import com.example.characteristics.domain.Game;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.List;

public class GameHbnRepo implements GameRepo{
    SessionFactory sessionFactory;

    public GameHbnRepo(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public Entity findOne(int id) {
        return null;
    }

    @Override
    public List<Game> findAll() {
        return null;
    }

    @Override
    public void save(Game order) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                session.save(order);
                tx.commit();
            } catch (RuntimeException ex) {
                System.err.println("Eroare la insert "+ex);
                if (tx != null)
                    tx.rollback();
            }
        }
    }

    @Override
    public void update(Integer id, Game user) {

    }
}
