package com.example.characteristics.domain;

import java.util.List;

public class ContainerLinesRound extends Entity<Integer>{

    List<Roundline> lines;
    Round rnd;

    public ContainerLinesRound(List<Roundline> lines, Round rnd) {
        this.lines = lines;
        this.rnd = rnd;
    }

    public List<Roundline> getLines() {
        return lines;
    }

    public void setLines(List<Roundline> lines) {
        this.lines = lines;
    }

    public Round getRnd() {
        return rnd;
    }

    public void setRnd(Round rnd) {
        this.rnd = rnd;
    }
}
