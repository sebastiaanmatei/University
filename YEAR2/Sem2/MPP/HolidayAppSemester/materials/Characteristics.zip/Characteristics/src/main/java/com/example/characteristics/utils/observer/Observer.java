package com.example.characteristics.utils.observer;

import com.example.characteristics.utils.events.Event;

public interface Observer<E extends Event> {
    void update(E e);
}