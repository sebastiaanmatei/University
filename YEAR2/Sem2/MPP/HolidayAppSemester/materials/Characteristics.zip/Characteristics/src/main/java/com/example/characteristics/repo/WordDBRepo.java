package com.example.characteristics.repo;

import com.example.characteristics.domain.User;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class WordDBRepo implements WordRepo<Integer>{

    private JdbcUtils dbUtils;
    private static final Logger logger = LogManager.getLogger();

    public WordDBRepo(Properties props) {
        logger.info("Initializing TripDBRepo with properties: {} ", props);
        dbUtils = new JdbcUtils(props);
    }

    @Override
    public String findOne(int id) {
        logger.traceEntry();
        Connection con = dbUtils.getConnection();
        try (PreparedStatement preStmt = con.prepareStatement("select name from words where id="+id)) {
            try (ResultSet result = preStmt.executeQuery()) {
                while (result.next()) {
                    String chosen = result.getString("name");
                    return chosen;

                }
            }
        } catch (SQLException e) {
            logger.error(e);
            System.err.println("Error DB" + e);
        }
        return null;
    }
}
