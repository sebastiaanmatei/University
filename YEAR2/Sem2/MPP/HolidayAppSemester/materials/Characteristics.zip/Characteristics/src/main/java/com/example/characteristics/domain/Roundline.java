package com.example.characteristics.domain;


import javax.persistence.Table;

@javax.persistence.Entity
@Table( name = "roundlines" )
public class Roundline extends Entity<Integer>{

    String player;
    String option1, option2;
    Integer score;
    Integer idRound;

    public Roundline(Integer id, String player, String option1, String option2, Integer score, Integer idRound) {

        super.setId(id);
        this.player = player;
        this.option1 = option1;
        this.option2 = option2;
        this.score = score;
        this.idRound = idRound;
    }

    public Roundline() {

    }

    public String getPlayer() {
        return player;
    }

    public void setPlayer(String player) {
        this.player = player;
    }

    public String getOption1() {
        return option1;
    }

    public void setOption1(String option1) {
        this.option1 = option1;
    }

    public String getOption2() {
        return option2;
    }

    public void setOption2(String option2) {
        this.option2 = option2;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getIdRound() {
        return idRound;
    }

    public void setIdRound(Integer idRound) {
        this.idRound = idRound;
    }
}
