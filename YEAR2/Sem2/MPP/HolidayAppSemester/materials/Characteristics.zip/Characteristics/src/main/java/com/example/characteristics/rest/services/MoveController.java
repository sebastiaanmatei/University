package com.example.characteristics.rest.services;


import com.example.characteristics.domain.Round;
import com.example.characteristics.domain.Roundline;
import com.example.characteristics.repo.RLineHbnRepo;
import com.example.characteristics.repo.RoundDBRepo;
import com.example.characteristics.repo.RoundRepo;
import com.example.characteristics.repo.RoundlineRepo;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@RestController
@RequestMapping("/com/example/characteristics")
public class MoveController {
    private final RoundRepo roundRepo;
    private final RoundlineRepo rlineRepo;


    public MoveController() {

        SessionFactory sessionFactory = null;

        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            System.err.println("Exception "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
        try {
            roundRepo=new RoundDBRepo(sessionFactory);
            rlineRepo=new RLineHbnRepo(sessionFactory);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @RequestMapping(value = "/{gameId}/words", method = RequestMethod.GET)
    public List<String> getRoundWords(@PathVariable("gameId") int gameId) {
        List<Round> rounds=roundRepo.findByGame(gameId);
        List<String> words=new ArrayList<>();
        for(Round r:rounds){
            System.out.println(r.getWord());
            if(r.getNumberOf()<4){
                words.add(r.getWord());
            }
        }
        return words;
    }

    @RequestMapping(value = "/{playerId}/{gameId}", method = RequestMethod.GET)
    public List<String> getPlayerCharacteristics(@PathVariable("playerId") String playerId,
                                                  @PathVariable("gameId") int gameId) {

        List<String> optionsScores=new ArrayList<>();
        List<Round> rounds=roundRepo.findByGame(gameId);
        for(Round r:rounds){
            if(r.getNumberOf()<4){
                List<Roundline> lines=rlineRepo.findResultsForRound(r.getId());
                if(lines.get(0).getPlayer().equals(playerId)){
                    optionsScores.add(lines.get(0).getOption1());
                    optionsScores.add(lines.get(0).getOption2());
                    optionsScores.add(String.valueOf(lines.get(0).getScore()));
                }
                if(lines.get(1).getPlayer().equals(playerId)){
                    optionsScores.add(lines.get(1).getOption1());
                    optionsScores.add(lines.get(1).getOption2());
                    optionsScores.add(String.valueOf(lines.get(1).getScore()));
                }
                if(lines.get(2).getPlayer().equals(playerId)){
                    optionsScores.add(lines.get(2).getOption1());
                    optionsScores.add(lines.get(2).getOption2());
                    optionsScores.add(String.valueOf(lines.get(2).getScore()));
                }
            }
        }
        return optionsScores;

    }


}
