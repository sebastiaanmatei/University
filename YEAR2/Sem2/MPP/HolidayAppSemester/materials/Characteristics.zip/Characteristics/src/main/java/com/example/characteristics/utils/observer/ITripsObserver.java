package com.example.characteristics.utils.observer;

import com.example.characteristics.domain.*;

import java.util.List;

public interface ITripsObserver {
    void updateRound(ContainerLinesRound container);
    void updateStats(List<Statistic> lines);
    void start(Game newGame, Round newRound);
}
