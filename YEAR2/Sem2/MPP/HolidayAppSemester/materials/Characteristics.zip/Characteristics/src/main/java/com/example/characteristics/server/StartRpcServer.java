package com.example.characteristics.server;


import com.example.characteristics.networking.utils.AbstractServer;
import com.example.characteristics.networking.utils.ServerException;
import com.example.characteristics.networking.utils.TripRpcConcurrentServer;
import com.example.characteristics.repo.*;
import com.example.characteristics.service.TripService;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import java.io.FileReader;
import java.io.IOException;

import java.util.Properties;

public class StartRpcServer {
    private static int defaultPort=55555;
    static SessionFactory sessionFactory;

    public static void main(String[] args) {
        // UserRepository userRepo=new UserRepositoryMock();
        Properties serverProps=new Properties();
        try {
            serverProps.load(new FileReader("bd.config"));
            System.out.println("Server properties set. ");
            serverProps.list(System.out);
        } catch (IOException e) {
            System.err.println("Cannot find chatserver.properties "+e);
            return;
        }


        try {
            initialize();
            HbnUserRepo HURepo=new HbnUserRepo(sessionFactory);
            WordDBRepo trepo =  new WordDBRepo(serverProps);
            UserDBRepo usrrepo =  new UserDBRepo(serverProps);
            OptionDBRepo rrepo =  new OptionDBRepo(serverProps);
            GameHbnRepo grepo= new GameHbnRepo(sessionFactory);
            RoundDBRepo rndrepo= new RoundDBRepo(sessionFactory);
            RLineHbnRepo rlinerepo= new RLineHbnRepo(sessionFactory);

            TripService service = new TripService(HURepo, trepo, rrepo, grepo, rndrepo, rlinerepo);

            int ServerPort=defaultPort;
            try {
                ServerPort = Integer.parseInt(serverProps.getProperty("server.port"));
            }catch (NumberFormatException nef){
                System.out.println("Wrong  Port Number"+nef.getMessage());
                System.out.println("Using default port "+defaultPort);
            }
            System.out.println("Starting server on port: "+ServerPort);
            AbstractServer server = new TripRpcConcurrentServer(ServerPort, service);
            try {
                server.start();
            } catch (ServerException e) {
                System.err.println("Error starting the server" + e.getMessage());
            }finally {
                try {
                    server.stop();
                }catch(ServerException e){
                    System.err.println("Error stopping server "+e.getMessage());
                }
            }



        }catch (Exception e){
            System.err.println("Exception "+e);
            e.printStackTrace();
        }finally {
            close();
        }




    }


    public static void initialize() {
        // A SessionFactory is set up once for an application!
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            System.err.println("Exception "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    static void close(){
        if ( sessionFactory != null ) {
            sessionFactory.close();
        }

    }


}
