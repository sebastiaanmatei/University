package com.example.characteristics.repo;

import com.example.characteristics.domain.Game;
import com.example.characteristics.domain.Round;
import com.example.characteristics.domain.Roundline;
import com.example.characteristics.domain.User;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Properties;

public class RoundDBRepo implements RoundRepo<Integer, Round>{
    SessionFactory sessionFactory;

    public RoundDBRepo(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public Round findOne(int id) {
        return null;
    }

    @Override
    public List<Round> findAll() {
        return null;
    }

    @Override
    public void save(Round order) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                session.save(order);
                tx.commit();
            } catch (RuntimeException ex) {
                System.err.println("Eroare la insert "+ex);
                if (tx != null)
                    tx.rollback();
            }
        }
    }

    @Override
    public void update(Integer id, Round rd) {

    }

    @Override
    public List<Round> findByGame(Integer id) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();

                org.hibernate.Query<Round> query1 = session.createQuery("from Round where idGame=: id", Round.class);
                query1.setParameter("id", id);
                List<Round> usr1= query1.getResultList();

                tx.commit();
                return usr1;
            } catch (RuntimeException ex) {
                ex.printStackTrace();
                System.err.println("Eroare la select "+ex);
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }


}
