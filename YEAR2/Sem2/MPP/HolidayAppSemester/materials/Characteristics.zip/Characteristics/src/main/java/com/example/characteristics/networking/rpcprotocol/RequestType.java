package com.example.characteristics.networking.rpcprotocol;

public enum RequestType {
    LOGIN, LOGOUT, START, ROUND, SEND_OPTIONS, GET_RESULTS, GET_STATS, GET_ALL_OPTIONS;
}
