package com.example.characteristics.repo;

import com.example.characteristics.domain.Entity;
import com.example.characteristics.domain.Roundline;
import com.example.characteristics.domain.Statistic;

import java.io.Serializable;
import java.util.List;

public interface RoundlineRepo <ID extends Serializable, E extends Entity<ID>>{

    E findOne (int id);

    List<Roundline> findAll();

    void save(Roundline user);

    void update(Integer id, Roundline user);

    List<Roundline> findResultsForRound(ID id);
}
