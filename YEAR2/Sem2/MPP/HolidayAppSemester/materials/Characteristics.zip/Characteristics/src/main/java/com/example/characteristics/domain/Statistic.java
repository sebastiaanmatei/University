package com.example.characteristics.domain;

public class Statistic extends Entity<Integer>{

    String player;
    Integer score;
    Integer idGame;

    public Statistic(Integer id, String player, Integer score, Integer idGame) {
        super.setId(id);
        this.player = player;
        this.score = score;
        this.idGame = idGame;
    }

    public String getPlayer() {
        return player;
    }

    public void setPlayer(String player) {
        this.player = player;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getIdGame() {
        return idGame;
    }

    public void setIdGame(Integer idGame) {
        this.idGame = idGame;
    }
}
