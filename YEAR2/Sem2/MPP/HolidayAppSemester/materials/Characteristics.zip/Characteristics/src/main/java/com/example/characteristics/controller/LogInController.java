package com.example.characteristics.controller;

import com.example.characteristics.HelloApplication;
import com.example.characteristics.domain.User;
import com.example.characteristics.networking.rpcprotocol.TripServicesRpcProxy;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.util.Random;

public class LogInController {

    TripServicesRpcProxy service;

    @FXML
    public TextField userField;
    @FXML
    public TextField passField;
    @FXML
    private Button loginButton;

    ManagementController controller;



    public void setService(TripServicesRpcProxy service) {
        this.service = service;
        //service.addObserver(this);
    }

    public Stage showPage(User user) {
        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("game.fxml"));
        Stage stage = new Stage(StageStyle.DECORATED);
        try {
            stage.setScene(
                    new Scene(loader.load())
            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        controller = loader.getController();
        controller.initData(user);
        controller.setService(service);
        stage.show();
        return stage;
    }

    /*@FXML
    protected void onLog() {

        boolean found = false;
        boolean valid = false;
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (!username.isEmpty() && !password.isEmpty()) {
            valid = true;
            User us = service.getEmployee(username, password);
            System.out.println(us.getIdUser()+" "+us.getUsername()+" "+us.getPassword());
            if (us!=null) {
                System.out.println(us.getUsername());
                //deschid fereastra noua cu user
                showPage(us);
                found = true;
            }
        }
        if (!valid || !found) {
            //System.out.println(0);
            MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Info", "User not found!");

        }


    }*/




    @FXML
    private void onLog(ActionEvent actionEvent){
        String username = userField.getText();
        String password = passField.getText();
        Random rand = new Random(); //instance of random class
        int upperbound = 10000;
        int id = rand.nextInt(upperbound);
        User toLogin=new User(id,username,password);


        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("game.fxml"));
        Stage stage = new Stage(StageStyle.DECORATED);
        try {
            stage.setScene(
                    new Scene(loader.load())
            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        controller = loader.getController();

        try{
            User employee=service.login(toLogin,controller);
            if (employee != null){
                controller.setService(service);
                controller.initData(employee);
                stage.show();

                ((Node)(actionEvent.getSource())).getScene().getWindow().hide();

            }

        }
        catch (Exception e){
            Alert alert=new Alert(Alert.AlertType.ERROR,e.getMessage());
            alert.show();
        }
    }



}

