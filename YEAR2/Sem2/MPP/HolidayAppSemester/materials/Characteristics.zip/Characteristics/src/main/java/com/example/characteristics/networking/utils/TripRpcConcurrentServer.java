package com.example.characteristics.networking.utils;

import com.example.characteristics.networking.rpcprotocol.TripClientRpcWorker;
import com.example.characteristics.service.TripService;
import java.net.Socket;

public class TripRpcConcurrentServer extends AbsConcurrentServer {
    private TripService service;
    public TripRpcConcurrentServer(int port, TripService service) {
        super(port);
        this.service = service;
        System.out.println("Chat- ChatRpcConcurrentServer");
    }

    @Override
    protected Thread createWorker(Socket client) {
        TripClientRpcWorker worker=new TripClientRpcWorker(service, client);

        Thread tw=new Thread(worker);
        return tw;
    }

    @Override
    public void stop(){
        System.out.println("Stopping services ...");
    }
}
