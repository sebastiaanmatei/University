package com.example.characteristics.service;


import com.example.characteristics.domain.*;
import com.example.characteristics.repo.*;
import com.example.characteristics.utils.observer.ITripsObserver;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TripService {
    private UserRepo<Integer, User> usrepo;
    private WordRepo<Integer> wrepo;
    private OptionDBRepo optrepo;
    private GameRepo<Integer, Game> gameRepo;
    private RoundRepo<Integer, Game> roundRepo;
    private RoundlineRepo<Integer, Game> rLineRepo;
    private StatsRepo<Integer, Game> statsRepo;
    private Map<Integer, ITripsObserver> loggedEmployees;

    private Map<String, ITripsObserver> gamingUsers;

    private Queue<String> waitingToPlay;

    private Queue<Roundline> linesSent;


    public TripService(UserRepo usrepo, WordRepo trepo, OptionDBRepo resrepo, GameRepo grepo, RoundRepo rrepo, RoundlineRepo rlinerepo) {
        this.usrepo=usrepo;
        this.wrepo=trepo;
        this.optrepo=resrepo;
        this.gameRepo=grepo;
        this.roundRepo=rrepo;
        this.rLineRepo=rlinerepo;
        loggedEmployees =new ConcurrentHashMap<>();
        gamingUsers=new ConcurrentHashMap<>();
        waitingToPlay=new LinkedList<>();
        linesSent=new LinkedList<>();
    }

    public synchronized User login(User employee, ITripsObserver client) throws Exception {
        User employeeToLogin=usrepo.findLog(employee.getUsername(),employee.getPassword());
        if (employeeToLogin!=null){
            if (loggedEmployees.get(employeeToLogin.getId())!=null)
                throw new Exception("Employee already logged in.");

            loggedEmployees.put(employeeToLogin.getId(),client);

        }
        else
            throw new Exception("Authentication failed.");
        return employeeToLogin;
    }


    public synchronized void logout(User employee, ITripsObserver client) throws Exception {
        ITripsObserver loggedEmployee= loggedEmployees.remove(employee.getId());
        if (loggedEmployee==null)
            throw new Exception("Employee "+String.valueOf(employee.getId())+" is not logged in.");
    }

    public synchronized ContainerGR start(String grp, ITripsObserver client) throws Exception{
        waitingToPlay.add(grp);
        gamingUsers.put(grp,client);
        ContainerGR container=new ContainerGR(1,null, null);

        if(waitingToPlay.size()>=3){
            Random rand = new Random(); //instance of random class
            int upperbound = 10000;
            int id = rand.nextInt(upperbound);
            int idr = rand.nextInt(upperbound);
            String us1=waitingToPlay.poll();
            String us2=waitingToPlay.poll();
            String us3=waitingToPlay.poll();
            Game newGame=new Game(id, us1, us2, us3, "started");
            gameRepo.save(newGame);


            int id2 = rand.nextInt(upperbound);
            int idWord = rand.nextInt(10);
            String word=wrepo.findOne(idWord);
            System.out.println(word);
            Round newRound=new Round(id2, word, newGame.getId(), 1);
            roundRepo.save(newRound);
            int count=1;

            for (ITripsObserver loggedUser: gamingUsers.values()) {
                //notifica playerii ca start
                System.out.println(count);
                count++;
                loggedUser.start(newGame, newRound);
                //gamingUsers.remove(loggedUser);
            }

            container.setGame(newGame);
            container.setId(idr);
            container.setRound(newRound);

            //return new ContainerGR(idr, newGame, newRound);
        }

        System.out.println(container.getGame()+" "+container.getRound());
        return container;


    }

    public synchronized ContainerLinesRound round(Round grp) throws Exception{

        Random rand = new Random(); //instance of random class
        int upperbound = 10000;
        int idr = rand.nextInt(upperbound);
        int idw = rand.nextInt(10);


        Integer id=grp.getId();
        ContainerLinesRound cnt=null;
        List<Roundline> lines=rLineRepo.findResultsForRound(id);

        //aici faci de fapt scorul le setezi la lines cu if uri

        if(lines.size()==3){
            int idnew = rand.nextInt(6);
            String word=wrepo.findOne(idnew);
            Round newRound=new Round(idr, word, grp.getIdGame(), grp.getNumberOf()+1);
            roundRepo.save(newRound);

            for (ITripsObserver loggedUser: gamingUsers.values()) {

                cnt=new ContainerLinesRound(lines, newRound);
                loggedUser.updateRound(cnt);

                if(grp.getNumberOf().equals(3)){
                    //afisat stats sau cv
                }
            }
        }
        return cnt;

    }

    public synchronized List<Statistic> getStats(Game grp, ITripsObserver client) throws Exception{

        Random rand = new Random(); //instance of random class
        int upperbound = 10000;


        Integer id=grp.getId();
        List<Statistic> stats=new ArrayList<>();
        List<Round> allrounds=roundRepo.findByGame(id);
        System.out.println(allrounds.get(0).getId());
        System.out.println(allrounds.get(1).getId());
        System.out.println(allrounds.get(2).getId());
        String pl1="", pl2="", pl3="";
        Integer score1=0, score2=0, score3=0;
        int count=1;
        for(Round r:allrounds){
            if(r.getNumberOf()<4){
                List<Roundline> alllines=rLineRepo.findResultsForRound(r.getId());
                pl1=alllines.get(0).getPlayer();
                pl2=alllines.get(1).getPlayer();
                pl3=alllines.get(2).getPlayer();
                System.out.println(pl3);

                score1=score1+alllines.get(0).getScore();
                score2=score2+alllines.get(1).getScore();
                score3=score3+alllines.get(2).getScore();
                System.out.println(score3);
            }


        }
        System.out.println("ajunge pana aici");
        int idr = rand.nextInt(upperbound);
        stats.add(new Statistic(idr, pl1, score1, id));
        idr = rand.nextInt(upperbound);
        stats.add(new Statistic(idr, pl2, score2, id));
        idr = rand.nextInt(upperbound);
        stats.add(new Statistic(idr, pl3, score3, id));
        System.out.println("o add");
        System.out.println(stats.size());



        for (ITripsObserver loggedUser: loggedEmployees.values()) {

            loggedUser.updateStats(stats);
        }
        return stats;
    }

    public synchronized Roundline scoreIt(Roundline grp, ITripsObserver client) throws Exception{
        //calculeaza scor si seteaza noul scor
        Random rand = new Random(); //instance of random class
        int upperbound = 10;
        int score = rand.nextInt(upperbound);

        grp.setScore(score);
        rLineRepo.save(grp);
        return grp;
    }

}
