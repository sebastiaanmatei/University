package com.example.characteristics;

import com.example.characteristics.controller.LogInController;
import com.example.characteristics.networking.rpcprotocol.TripServicesRpcProxy;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.scene.layout.VBox;
import java.io.FileReader;
import java.util.Properties;

public class HelloApplication extends Application {

    TripServicesRpcProxy service;
    private static int defaultChatPort=55555;
    private static String defaultServer="localhost";


    @Override
    public void start(Stage stage) throws IOException {



        System.out.println("In start");
        Properties clientProps = new Properties();
        try {
            clientProps.load(new FileReader("clientProperties"));
            System.out.println("Client properties set. ");
            clientProps.list(System.out);
        } catch (IOException e) {
            System.err.println("Cannot find client.properties " + e);
            return;
        }
        String serverIP = clientProps.getProperty("server.host", defaultServer);
        int serverPort = defaultChatPort;

        try {
            serverPort = Integer.parseInt(clientProps.getProperty("server.port"));
        } catch (NumberFormatException ex) {
            System.err.println("Wrong port number " + ex.getMessage());
            System.out.println("Using default port: " + defaultChatPort);
        }
        System.out.println("Using server IP " + serverIP);
        System.out.println("Using server port " + serverPort);
        TripServicesRpcProxy service=new TripServicesRpcProxy(serverIP,serverPort);

        //initView(stage);

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("login.fxml"));
        VBox userLayout = fxmlLoader.load();
        stage.setScene(new Scene(userLayout));

        LogInController userController = fxmlLoader.getController();
        userController.setService(service);

        stage.show();


    }

    public static void main(String[] args) {
        launch(args);
    }




}












/*private void initView(Stage primaryStage) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("firstpage.fxml"));
        VBox userLayout = fxmlLoader.load();
        primaryStage.setScene(new Scene(userLayout));

        LogInController userController = fxmlLoader.getController();
        userController.setService(service);

    }*/
    /*Properties props = new Properties();
        try {
            props.load(new FileReader("bd.config"));
        } catch (IOException e) {
            System.out.println("Cannot find bd.config " + e);
        }

        TripDBRepo trepo =  new TripDBRepo(props);
        UserDBRepo usrrepo =  new UserDBRepo(props);
        ResDBRepo rrepo =  new ResDBRepo(props);

        service = new Service(usrrepo, trepo, rrepo);
        initView(stage);
        stage.show();*/



