package com.example.characteristics.domain;


import javax.persistence.Table;

@javax.persistence.Entity
@Table( name = "rounds" )
public class Round extends Entity<Integer>{

    String word;
    Integer idGame;

    Integer numberOf;

    public Round(Integer id, String word ,Integer idGame, Integer numberOf) {

        super.setId(id);
        this.word = word;
        this.idGame = idGame;
        this.numberOf=numberOf;
    }

    public Round() {

    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public Integer getIdGame() {
        return idGame;
    }

    public void setIdGame(Integer idGame) {
        this.idGame = idGame;
    }

    public Integer getNumberOf() {
        return numberOf;
    }

    public void setNumberOf(Integer numberOf) {
        this.numberOf = numberOf;
    }
}
