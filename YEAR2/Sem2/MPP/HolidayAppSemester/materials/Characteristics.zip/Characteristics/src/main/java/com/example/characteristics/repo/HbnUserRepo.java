package com.example.characteristics.repo;

import com.example.characteristics.domain.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import javax.persistence.Query;
import java.util.List;

public class HbnUserRepo implements UserRepo{

    SessionFactory sessionFactory;

    public HbnUserRepo(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public User findOne(int id) {
        return null;
    }

    //FIND USER
    public User findLog(String user, String pass){
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();

                String hql = "FROM User WHERE username = :username AND password = :password";
                Query query = session.createQuery(hql, User.class);
                //List<User> logged= query.getResultList();
                //System.out.println(logged.size());
                //User usr=logged.get(0);

                org.hibernate.Query<User> query1 = session.createQuery("from User where username = :username and password = :password", User.class);
                query1.setParameter("username", user);
                query1.setParameter("password", pass);
                System.out.println("user:" + user);
                System.out.println("pass:" + pass);
                User usr1= query1.getSingleResult();




                tx.commit();
                return usr1;
            } catch (RuntimeException ex) {
                ex.printStackTrace();
                System.err.println("Eroare la select "+ex);
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;


    }

    @Override
    public List<User> findAll() {
        return null;
    }

    @Override
    public void save(User user) {

    }

    @Override
    public void update(Integer id, User user) {

    }

    @Override
    public void delete(String username) {

    }

}
