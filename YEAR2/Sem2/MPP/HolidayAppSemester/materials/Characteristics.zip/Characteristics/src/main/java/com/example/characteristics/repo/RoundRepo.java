package com.example.characteristics.repo;

import com.example.characteristics.domain.Entity;
import com.example.characteristics.domain.Round;
import com.example.characteristics.domain.Statistic;

import java.io.Serializable;
import java.util.List;

public interface RoundRepo <ID extends Serializable, E extends Entity<ID>>{

    E findOne (int id);

    List<Round> findAll();

    void save(Round user);

    void update(Integer id,  Round rd);

    List<Round> findByGame(Integer id);
}
