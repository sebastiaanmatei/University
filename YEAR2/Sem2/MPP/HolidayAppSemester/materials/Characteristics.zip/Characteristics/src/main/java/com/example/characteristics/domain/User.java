package com.example.characteristics.domain;
import javax.persistence.*;

@javax.persistence.Entity
@Table( name = "players" )

public class User extends Entity<Integer> {
    String username;
    String password;

    public User() {
        // no-arg constructor required by Hibernate
    }

    public User(Integer id) {
        setId(id);
    }

    public User(Integer id, String username, String password) {
        setId(id);
        this.username = username;
        this.password = password;
    }

    /*
    @Transient
    public Integer getIdUser(){
        return getId();
    }

    public void setId(Integer id){
        super.setId(id);
    } */


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
