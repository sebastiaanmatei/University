package com.example.characteristics.utils.events;

public interface Event {
}
