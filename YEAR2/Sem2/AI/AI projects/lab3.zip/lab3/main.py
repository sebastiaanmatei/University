import tests

if __name__ == '__main__':
    print('choose option 1-8')
    var = int(input('file:'))
    if (var == 1):
        tests.test1()

    if (var == 2):
        tests.test2()

    if (var == 3):
        tests.test3()

    if (var == 4):
        tests.test4()

    if (var == 5):
        tests.test5()

    if (var == 6):
        tests.test6()

    if (var == 7):
        tests.test7()

    if (var == 8):
        tests.test8()

    if (var == 9):
        tests.test9()

    if (var == 10):
        tests.test10()
    if (var == 11):
        tests.testmare()
