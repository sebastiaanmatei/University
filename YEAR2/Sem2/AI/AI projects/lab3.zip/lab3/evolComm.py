import networkx as nx
import random


def initialize_population(G, pop_size):
    population = []
    for i in range(pop_size):
        partition = {}
        nodes = list(G.nodes())
        random.shuffle(nodes)
        num_communities = random.randint(2, int(len(nodes) / 2))
        for node in nodes:
            min_community = None
            min_community_size = float('inf')
            for c in range(len(partition)):
                community_size = len(partition[c])
                if community_size < min_community_size:
                    min_community = c
                    min_community_size = community_size
            if min_community is None or min_community_size >= len(nodes) / num_communities:
                partition[len(partition)] = [node]
            else:
                partition[min_community].append(node)
        population.append(partition)
    return population



def calculate_modularity(G, partition):
    num_edges = G.number_of_edges()
    num_communities = len(partition)
    modularity = 0.0
    for c in range(num_communities):
        community = partition[c]
        community_size = len(community)
        community_edges = G.subgraph(community).number_of_edges()
        degr=dict(G.degree(community))
        community_degree = sum(degr.values())
        modularity += community_edges / num_edges - (community_degree / (2 * num_edges)) ** 2
    return modularity



def evolutive_algorithm(G, pop_size, num_generations):
    population = initialize_population(G, pop_size)
    for i in range(num_generations):
        fitnesses = [(p, calculate_modularity(G, p)) for p in population]
        fitnesses.sort(key=lambda x: x[1], reverse=True)
        elite = [fitnesses[j][0] for j in range(pop_size // 5)]
        offspring = []
        while len(offspring) < pop_size - len(elite):
            parent1, parent2 = random.sample(elite, 2)
            child = {}
            for c in range(len(parent1)):
                if random.random() < 0.5:
                    child[c] = parent1[c]
                else:
                    child[c] = parent2[c]
            offspring.append(child)
        population = elite + offspring
        for partition in population:
            for c in range(len(partition)):
                if random.random() < 0.05:
                    node = random.choice(partition[c])
                    new_c = random.randint(0, len(partition) - 1)
                    partition[c].remove(node)
                    partition.setdefault(new_c, []).append(node)
    best_partition = max([(p, calculate_modularity(G, p)) for p in population], key=lambda x: x[1])[0]
    return best_partition
