import networkx as nx
import comm


def test1():
    Graph = nx.read_gml('dolph.gml')
    structure=comm.genetic_algorithm(Graph, 100, 10, 0.01, 100)
    for i, community in enumerate(structure):
        print(f"Community {i + 1}: {community}")


def test2():
    Graph = nx.read_gml('football.gml')
    structure=comm.genetic_algorithm(Graph, 100, 10, 0.01, 100)
    for i, community in enumerate(structure):
        print(f"Community {i + 1}: {community}")

def test3():
    Graph = nx.read_gml('karate.gml', label="id")
    structure=comm.genetic_algorithm(Graph, 100, 10, 0.01, 100)
    for i, community in enumerate(structure):
        print(f"Community {i + 1}: {community}")

def test4():
    Graph = nx.read_gml('krebs.gml')
    structure=comm.genetic_algorithm(Graph, 100, 10, 0.01, 100)
    for i, community in enumerate(structure):
        print(f"Community {i + 1}: {community}")

def test5():
    Graph = nx.read_gml('test1.gml')
    structure=comm.genetic_algorithm(Graph, 100, 10, 0.01, 100)
    for i, community in enumerate(structure):
        print(f"Community {i + 1}: {community}")

def test6():
    Graph = nx.read_gml('test2.gml')
    structure=comm.genetic_algorithm(Graph, 100, 10, 0.01, 100)
    for i, community in enumerate(structure):
        print(f"Community {i + 1}: {community}")

def test7():
    Graph = nx.read_gml('fruits.gml')
    structure=comm.genetic_algorithm(Graph, 100, 10, 0.01, 100)
    for i, community in enumerate(structure):
        print(f"Community {i + 1}: {community}")

def test8():
    Graph = nx.read_gml('random.gml')
    structure=comm.genetic_algorithm(Graph, 100, 10, 0.01, 100)
    for i, community in enumerate(structure):
        print(f"Community {i + 1}: {community}")

def test9():
    f = open("rezLesmis.txt", "w")
    Graph = nx.read_gml('lesmis.gml')
    structure=comm.genetic_algorithm(Graph, 100, 10, 0.01, 100)
    for i, community in enumerate(structure):
        f.write(f"Community {i + 1}: {community}")
        f.write("\n")
    f.close()


def test10():
    f = open("rezNetscience.txt", "w")
    Graph = nx.read_gml('netscience.gml')
    structure=comm.genetic_algorithm(Graph, 100, 10, 0.01, 100)
    for i, community in enumerate(structure):
        f.write(f"Community {i + 1}: {community}")
        f.write("\n")
    f.close()


def testmare():
    Graph=nx.read_edgelist('testmare.gml')
    f = open("rezNetscience.txt", "w")
    structure = comm.genetic_algorithm(Graph, 100, 10, 0.01, 100)
    for i, community in enumerate(structure):
        f.write(f"Community {i + 1}: {community}")
        f.write("\n")
    f.close()







