import random
import networkx as nx


# definim functia de fitness
def evaluate(individual, G):
    partitions = {}
    for node, community in zip(G.nodes(), individual):
        if community not in partitions:
            partitions[community] = set()
        partitions[community].add(node)
    modularity = nx.algorithms.community.modularity(G, list(partitions.values()))
    return modularity,


# algoritmul genetic
def genetic_algorithm(G, population_size, elite_size, mutation_rate, generations):
    # creeam populatia
    population = []
    for i in range(population_size):
        individual = [random.randint(0, population_size) for node in G.nodes()]
        population.append(individual)

    for generation in range(generations):
        # evaluam fitness ul fiecarui individ
        fitness = [evaluate(individual, G) for individual in population]

        # alegem cel mai bun individ
        elite = sorted(range(len(fitness)), key=lambda i: fitness[i], reverse=True)[:elite_size]

        # creeam urmatoarea generatie
        next_generation = []
        for i in range(population_size - elite_size):
            # selectam 2 parinti
            parent1 = population[random.randint(0, population_size - 1)]
            parent2 = population[random.randint(0, population_size - 1)]

            # crossover parinti
            crossover_point = random.randint(1, len(parent1) - 1)
            child = parent1[:crossover_point] + parent2[crossover_point:]

            # mutatie copil
            for j in range(len(child)):
                if random.random() < mutation_rate:
                    child[j] = random.randint(0, population_size)

            next_generation.append(child)

        # adaugam cei mai buni indivizi in urmatoarea populatie
        for i in elite:
            next_generation.append(population[i])

        population = next_generation

    # alegem cea mai buna varianta
    fitness = [evaluate(individual, G) for individual in population]
    best_individual = population[max(range(len(fitness)), key=lambda i: fitness[i])]

    # construim partitia de la cea mai buna varianta
    partition = {}
    for node, community in zip(G.nodes(), best_individual):
        if community not in partition:
            partition[community] = set()
        partition[community].add(node)

    return partition.values()